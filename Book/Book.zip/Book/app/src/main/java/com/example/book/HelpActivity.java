package com.example.book;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        // Initialize TextViews for each instruction
        TextView instruction1 = findViewById(R.id.instruction1);
        TextView instruction2 = findViewById(R.id.instruction2);
        TextView instruction3 = findViewById(R.id.instruction3);
        TextView instruction4 = findViewById(R.id.instruction4);
        TextView instruction5 = findViewById(R.id.instruction5);

        // Set the help instructions
        instruction1.setText("1. To sell a book, click on 'Sell Book' and follow the prompts to add your book details.");
        instruction2.setText("2. To buy a book, click on 'Buy Book' and browse through the available books.");
        instruction3.setText("3. For assistance, click on 'Help' to access this Help section.");
        instruction4.setText("4. To log out, simply click on 'Logout' at any time.");
        instruction5.setText("5. Enjoy using Book App! For further assistance, contact support.");
    }
}
