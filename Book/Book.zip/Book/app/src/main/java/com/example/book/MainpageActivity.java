package com.example.book;



import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainpageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        // Initialize buttons
        Button sellBookButton = findViewById(R.id.buttonSellBook);
        Button buyBookButton = findViewById(R.id.buttonBuyBook);
        Button helpButton = findViewById(R.id.buttonHelp);
        Button logoutButton = findViewById(R.id.buttonLogout);

        // Set OnClickListener for the Sell Book button
        sellBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to AddBookActivity when the Sell Book button is clicked
                Intent intent = new Intent(MainpageActivity.this, AddBookActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the Buy Book button
       /* buyBookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add logic to navigate to the BuyBookActivity
                // For example:
                Intent intent = new Intent(MainpageActivity.this, BuyBookActivity.class);
                startActivity(intent);
            }
        });*/

        // Set OnClickListener for the Help button
        helpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Add logic to navigate to the HelpActivity
                // For example:
                Intent intent = new Intent(MainpageActivity.this, HelpActivity.class);
                startActivity(intent);
            }
        });

        // Set OnClickListener for the Logout button
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call logoutUser() to handle logout
                logoutUser();

                // Navigate to the LoginRegister activity
                Intent intent = new Intent(MainpageActivity.this, LoginRegister.class);
                startActivity(intent);
                finish(); // Finish current activity to prevent going back to MainpageActivity
            }
        });
    }

    private void logoutUser() {
        // Add logic to logout the user
        // For example:
        // Clear user session, navigate to login screen, etc.
    }
}

