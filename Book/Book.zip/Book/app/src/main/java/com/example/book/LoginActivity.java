package com.example.book;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText editTextUsername, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize EditText fields
        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
    }

    // Method to handle Login button click
    public void onLoginClicked(View view) {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();

        // Perform validation checks (e.g., check if username and password are not empty)
        if (!username.isEmpty() && !password.isEmpty()) {
            // Here you can add your login logic, such as checking credentials against a database
            // For demonstration purposes, simply show a Toast indicating successful login
            Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();

            // Start MainActivity or any other activity upon successful login
            Intent intent = new Intent(this, MainpageActivity.class);
            startActivity(intent);
            finish(); // Close LoginActivity to prevent back navigation
        } else {
            // Show error message if username or password is empty
            Toast.makeText(this, "Please enter username and password", Toast.LENGTH_SHORT).show();
        }
    }
}
